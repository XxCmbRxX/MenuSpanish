smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, ("Wow! Apareciste en\
medio de un batallon.\
Encontraras las Estrellas\
de Poder que Bowser\
robo dentro de las\
pinturas.\
Primero, habla con ese\
Bob-Omba Aliado. (Pulsa\
[B] para hablar.)\
El y sus  amigos\
te ayudaran en\
diferentes areas.\
Para leer letreros,\
detente, miralos y pulsa\
[B]. Presiona [A] o [B]\
para seguir leyendo.\
Puedes hablar con otros\
personajes viendolos y\
presionando [B]."))

smlua_text_utils_dialog_replace(DIALOG_001,1,4,95,200, ("Cuidado! Si merodeas\
por ahi, podrias ser\
APLASTADO por una\
Aqua-Bomba! Esos\
Bob-Ombas aman pelear,\
y siempre buscan\
maneras para atacar.\
Este prado se convirtio\
en un batallon desde\
que el Gran Bob-Omba\
tiene esa Estrella de\
Poder. Puedes recuperar\
la Estrella? Pasa el\
puente y ve a la izquierda\
alli encontraras a el Gran\
Bob-Omba. Por favor\
regresa cuando recuperes\
la Estrella de Poder!"))

smlua_text_utils_dialog_replace(DIALOG_002,1,4,95,200, ("Oye, tu! Es peligroso\
estar aqui, asi que\
escucha mi consejo.\
\
Cruza los 2 puentes que\
estan adelante, luego\
ten cuidado de las\
Aqua-Bombas.\
El Gran Bob-omba que\
esta en la cima es\
muy poderoso, no te\
dejes que te atrape!\
Somos Bob-Ombas aliados,\
y estamos de tu lado.\
Puedes hablarnos\
cuando lo desees!"))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("Gracias Mario! El Gran\
Bob-Omba no es nada para\
ti ahora! Pero la\
battala por el castillo\
ha comenzado.\
Otros enemigos tendran\
otras Estrellas. Si\
recuperas mas Estrellas,\
abriras mas puertas que\
llevaran a mas mundos!\
Mis Amigos Bob-Omba te\
estan esperando.\
Habla con ellos, abriran\
los canones por ti."))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, ("Somos bob-ombas\
pacificas, asi que no\
usamos canones.\
Pero si te quieres\
lanzar no lo pensaremos.\
Te ayudaremos.\
Prepararemos todos los\
canones en este nivel.\
Bon Voyage!"))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, ("Oye, Mario! Es cierto\
que venciste al Gran\
Bob-Omba? Bien!\
Debes ser fuerte. Y muy\
rapido. Bueno, que tan\
rapido eres?\
Lo suficiente para poder\
vencerme... A mi? No lo\
lo creo. Para nada.\
Que opinas de una carrera\
a la cima de la montana\
donde el Gran Bob-Omba\
estaba. Que dices? Cuando\
diga Ahora, la carrera\
empieza!\
Listo....\
\
//Ya!////Espera"))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Oye!!! no trates de\
Hacer trampa Corre\
alrededor del nivel.\
Despues. Buscame\
para una verdadera\
carrera."))

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, ("Hufff...fff...pufff...\
Wow! Si...que...eres...\
rapido! Una Bala Humana!\
Aqui tienes, has ganado\
justa y limpiamente!"))

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, ("CUIDADO, CHAIN CHOMP\
Peligro extremo!\
Acercate y presiona [C]^\
para una mejor vista.\
Da miedo, verdad?\
Vez esa moneda roja\
arriba del tronco?\
\
Cuando tengas 8 de ellas,\
una estrella aparecera\
en la pradera cruzando\
el puente."))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Hola de nuevo! Wow,\
te has hecho mas rapido!\
Has estado entrenando\
disimuladamente, o es\
el poder de las estrellas?\
He estado desanimado\
por perder la carrera\
anterior. Esta es mi casa\
que opinas, tendrias una\
revancha?\
La meta es en el\
Valle Ventoso.\
Listo?\
\
//Ya!////Espera"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("Acabas de presionar el\
Switch de la Gorra Alada!\
Con esta gorra, puedes\
surcar por los cielos.\
Ahora la Gorra Alada\
aparecera en todos los\
bloques rojos que veas.\
\
Quieres Guardar?\
\
//Si////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("Acabas de presionar el\
Switch de la Gorra\
Metalica! Esta hace\
a Mario invencible.\
Ahora la Gorra Metalica\
aparecera en todos los\
bloques verdes que veas.\
\
Quieres Guardar?\
\
//Si////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("Acabas de presionar el\
Switch de la Gorra\
Invisible! Esta hara\
desaparecer a Mario.\
Ahora la Gorra Invisible\
aparecera en todos los\
bloques azules que veas.\
\
Quieres Guardar?\
\
//Si////No"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("Conseguiste 100\
monedas! Mario obtiene\
mas poder del castillo.\
Quieres Guardar?\
//Si////No"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Wow! Otra Estrella!\
Mario gana mas\
valentia gracias al\
poder del castillo.\
Quieres Guardar?\
\
//Claro!//No Ahora"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("Puedes golpear enemigos\
para derrotarlos. Pulsa [A]\
para saltar, [B] para pegar.\
Pulsa [A] seguido de [B]\
para patear. Para agarrar\
algo, pulsa [B]. Para tirar\
algo que agarres,\
pulsa [B] de nuevo."))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("Subete a este caparazon y\
ve hacia donde quieras!\
Acaba con esos enemigos!"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("Soy el Gran Bob-Omba,\
maestro de la materia\
explosiva, rey de las\
bombas en este mundo!\
Como te atreves a pasar\
por mis tierras? Con\
que derecho pisas\
esta cima?\
Puede que hayas evadido\
a mis guardias, pero nunca\
escaparas de la furia real.\
\
...Jamas obtendras\
mi estrella de poder.\
Asi que te desafio,\
Mario!\
Si quieres mi estrella,\
deberas ganarmela en\
batalla.\
\
Podras agarrarme de\
la espalda en mi\
propia arena real?\
No lo creo!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("Estoy durmiendo por que\
estoy...cansado. No me\
gusta que me molesten.\
Camina con cuidado."))

smlua_text_utils_dialog_replace(DIALOG_019,1,2,30,200, ("Shhh! Por favor camina\
despacio en el pasillo!"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("Querido Mario:\
Porfavor ven al\
castillo. Hornee\
un pastel para ti.\
Atentamente--\
Princesa Toadstool"))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, ("Bienvenido.\
Nadie esta en casa!\
Ahora LARGATE!!\
y no vuelvas!\
Mua ja ja!"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("Necesitas una llave para\
abrir esta puerta."))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, ("Esta llave no entra!\
Tal vez sea para\
el sotano..."))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, ("Necesitas poder Estelar\
para abrir esta puerta.\
Consigue mas Estrellas de\
los enemigos en las\
pinturas del castillo."))

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, ("Se necesita el poder\
de 3 estrellas para\
abrir esta puerta.\
Necesitas  mas."))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, ("Se necesita el poder\
de 8 estrellas para\
abrir esta puerta.\
Necesitas  mas."))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, ("Se necesita el poder\
de 30 estrellas para\
abrir esta puerta.\
Necesitas  mas."))

smlua_text_utils_dialog_replace(DIALOG_028,1,4,95,200, ("Se necesita el poder\
de 50 estrellas para\
abrir esta puerta.\
Necesitas  mas."))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, ("Para abrir la puerta que\
lleva a las escaleras\
INFINITAS, necesitas 70\
Estrellas.\
Mua ja ja!"))


smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, ("Hola! Los hermanos Lakitu,\
Entrando con una emision\
En vivo del progreso de\
Mario. El esta apunto de\
aprender una tecnica para\
escabullirse de sus\
enemigos. El truco es:\
caminar lentamente para\
no hacer ruido.\
\
\
\
Terminando nuestro\
informe, repasemos unas\
tecnicas, puedes mirar \
alrededor usando [C]> y\
[C]<. Presiona [C]| para\
ver la accion desde la\
distancia. Cuando no\
puedas mover la camara,\
escucharas un zumbido.\
Somos los hermanos\
Lakitu, despidiendose."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("No puede ser! Me \
venciste... otra vez!!\
Y yo que gaste mis\
ahorros enteros en los\
Koopa Mach 1 Sprint!\
Toma, creo que debo\
darte esta estrella\
por ganar la carrera.\
Felicidades, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, ("Si consigues la Gorra,\
Alada volaras! Pontela,\
luego has  un Triple\
Salto--salta tres veces\
seguidas para volar.\
Puedes volar mas alto\
si te lanzas de un\
canon mientras usas\
la Gorra Alada!\
\
Usa el boton [C] para\
mirar mientras vuelas,\
pulsa [Z] para aterrizar."))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, ("Hola! Has llegado al\
castillo de la Princesa\
Toadstool por una tuberia.\
Usar el control es pan\
comido. Pulsa [A] para\
saltar y [B] para atacar.\
Pulsa [B] para leer los\
carteles. Usa el Control\
Stick en el centro del\
control para mover a\
Mario alrededor. Ahora,\
dirigete al castillo."))

smlua_text_utils_dialog_replace(DIALOG_034,1,6,30,200, ("Buenas tardes. Los\
Hermanos Lakitu\
reportando en vivo,\
justo afuera del\
castillo de la\
Princesa.\
Mario acaba de entrar en\
la escena, y nosotros\
Estaremos grabando\
mientras entra al castillo\
y persigue las Estrellas\
perdidas.\
Como expertos, estaremos\
grabando desde el angulo\
recomendado, pero puedes\
cambiar el angulo de\
la camara presionando\
Los botones [C].\
Si no podemos ajustar\
la vista mas, haremos un\
un zumbido. Para echar\
un vistazo a tus\
alrededores presiona\
el boton [C]^.\
Presiona [A] para\
resumir el juego. Cambia\
la camara con el boton\
[R]. Los carteles a traves\
del camino te recordaran\
estas instrucciones.\
Por ahora, reportando en\
vivo, Los Hermanos\
Lakitu."))

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, ("Hay 4 tipos de camara, o\
botones [C], . Presiona\
[C]^ para mirar a tu\
alrededor usando el\
Control Stick.\
Usualmente veras a Mario\
a travez de la camara de\
Lakitu. Esta es la que\
se recomienda para jugar\
normalmente.\
Puedes cambiar los\
angulos presionando [C].\
Si apretas [R], la camara\
cambia a la de Mario,\
esta esta detras de el.\
Presiona [R] para volver\
a la camara anterior.\
Presiona [C]| para ver a\
mario desde lejos, no\
importa que camara uses."))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("PISO DE OBSERVACION\
Presiona [C]^ para hechar\
un vistazo alrededor. No\
te pierdas de nada!\
\
Presiona [R] para cambiar a\
la camara Mario. Esta\
siempre seguira a Mario.\
Presiona [R] de nuevo para\
cambiar a camara Lakitu.\
Pausa el juego y cambia\
el modo para arreglar\
la camara de lugar\
mientras presionas [R] .\
Dale un intento!"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("Yo gano! Tu pierdes!\
Ja ja ja ja!\
No eres vago, pero soy\
mejor corredor!\
Suerte a la proxima!"))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("Reaccionando al poder\
Estelar, la puerta\
se abre lentamente."))

smlua_text_utils_dialog_replace(DIALOG_039,1,4,30,200, ("No visitantes,\
decreto del\
Gran Bob-Omba\
\
Nunca entregare mi\
Estrella, porque tiene\
poder del castillo en\
su brillo\
Fue un regalo de\
Bowser, el Rey Koopa,\
y esta escondida en\
mi reino.\
Ni un susurro de donde\
se encuentran dejaran\
mis labios. Oh, okay,\
toma una pista:\
Lee los nombres al\
inicio de los\
niveles.\
//--El Gran Bob-Omba"))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("Cuidado!\
Barranco Nevado.\
Cuida tus pasos!"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("Yo gano! Tu pierdes!\
Ja ja ja!\
\
Es lo que obtienes por\
meterte con Koopa el\
Veloz.\
Suerte a la proxima!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,4,30,200, ("Precaucion! Cordal Largo!\
Cruzar con precaucion!\
\
\
Puedes saltar a la orilla\
para agarrarte de esta,\
y puedes subir por el\
borde si te mueves lento.\
Si quieres dejar ir,\
presiona [Z] o mueve\
el Control Stick en\
direccion trasera a Mario.\
Para subir, hala arriba\
en el Control Stick. Para\
subir mas rapido, presiona\
el boton [A]."))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("Si saltas y dejas\
presionado el boton [A],\
puedes quedarte sujeto a\
algunos objetos arriba de\
ti. Es igual que\
agarrarse a una lechuza!"))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("Quieeen esta ahi Quien\
me desperto? Todavia es\
de dia--deberia estar\
durmiendo!\
\
Oye, ahora que desperte,\
porque no tomas un corto\
vuelo conmigo? Deja\
pulsado [A] para agarrarte\
Suelta [A] para soltarse.\
Te llevare a donde sea\
mientras mis alas puedan\
soportar tu peso.\
Ve mi sombra, y agarra\
tu bigote."))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, ("Puf! Me estoy muriendo\
del cansancio. Deberias\
ponerte a dieta, Mario!\
Mucho por hoy, pulsa\
[A] para soltarte. Okay,\
nos vemos , chauu!"))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("Tienes que dominar las\
tres tecnicas de salto\
importantes.\
Prueba un Triple Salto.\
\
Corre rapido, luego salta\
tres veces, 1, 2 y 3!.\
Si logras hacer los 3\
saltos seguidos, haras\
un salto muy alto!.\
Luego, ve lejos con un\
Salto Largo. Corre y,\
pulsa [Z]. Seguido pulsa\
[A] para saltar muy lejos.\
\
Para hacer el Salto\
Pared, pulsa [A] y\
salta a la pared,\
salta otra vez para\
llegar a la otra pared.\
Lo captaste? Triple Salto,\
Salto Largo, Salto Pared.\
Practica, practica,\
practica. No lo lograras\
sin ellos."))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Hola! Preparare el\
canon para ti!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, ("Colina nevada adelante.\
Cuidado con el suelo\
resbaladizo! Entra a la\
cabana primero."))

smlua_text_utils_dialog_replace(DIALOG_049,1,5,30,200, ("Te acuerdas de ese Salto\
Pared? Es una tecnica\
que tienes que practicar\
constantemente para \
llegar a lugares altos.\
Usalo para saltar de \
pared en pared. Mueve\
el Control Stick hacia\
la direccion que quieres\
para ganar inercia. La\
practica hace al maestro!"))

smlua_text_utils_dialog_replace(DIALOG_050,1,4,30,200, ("Manten [Z] para agacharse\
y resbalar por la cuesta\
O pulsa [Z] en el aire\
para dar un gran Pisoton!\
Si paras, te agachas y\
saltas, haras una\
Voltereta! Entiendes?\
Hay mas. Si te agachas\
luego saltas haras un\
Salto Largo! o si te\
agachas y caminas\
...mejor olvidalo."))

smlua_text_utils_dialog_replace(DIALOG_051,1,6,30,200, ("Escalar es muy facil\
cuando saltes a postes\
o arboles, te agarras\
automaticamente. Pulsa\
[A] para saltar.\
\
Para girar alrededor,\
mueve el Control Stick\
a la derecha o izquierda.\
Cuando llegues a la cima,\
muevete hacia delante\
para pararte de manos!\
Salta de la cima para\
tener una salida con\
mucho estilo."))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("Detente y pulsa [Z] para\
agacharse, luego pulsa [A]\
para hacer una Voltereta\
hacia atras!\
\
Para hacer una \
Voltereta Diagonal\
corre, gira en U y salta.\
Puedes conseguir mucha\
altura con estos saltos."))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("A veces, si pasas por un\
bloque hecho de monedas\
o encuentras un secreto\
del mundo, un numero\
rojo aparecera.\
Si encuentras los 5\
numeros secretos una\
Estrella aparecera."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("Bienvenido a la\
resbaladilla helada!\
Subete, para poder\
acelerar mueve el\
Control stick adelante\
Y frenar, para atras."))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("Oye, Mario, amigo,\
Como estas? Da un paso\
adelante. Te ves como\
un chico veloz.\
Conozco la velocidad\
cuando la veo, si senor,\
soy el campeon mundial en\
las carreras, Que dices?\
Te echas una carrera?\
Listo...\
\
//Ya!//// Espera"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("R-r-rompiste mi record!\
Increible! Sabia\
que eras el mas cool.\
Haz probado\
que tambien eres\
el mas rapido!\
No puedo darte una\
medalla, pero ten esta\
estrella a cambio.\
Te lo has ganado!"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Dios mio! mi bebe! Haz\
visto a mi bebe??? Es la\
bebe mas hermosa de toda\
la galaxia.\
(Dicen que su pico es igual\
al mio...) No recuerdo\
donde la deje a la\
pobre.\
Veamos... me detuve\
por arenque y hielos,\
y luego...ohhh! Simplemente\
no recuerdo!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("Encontraste a mi preciosa\
bebe! Donde has estado\
pequena? Como puedo\
darte las gracias, Mario?\
Oh, tengo esta...\
...estrella. Tomala\
como muestra de mi\
eterna gratitud."))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("Esa no es mi bebe! Ella\
ni se parece a mi!\
Sus padres deben estar\
muy preocupados!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("ATENCION!\
Lea antes de sumergirse!\
\
\
Si te quedas en el agua\
por mucho tiempo, te\
quedaras sin oxigeno.\
\
Regresa a la superficie\
por aire o usa una burbuja\
o monedas para recuperar\
el oxigeno.\
Pulsa [A] para nadar.\
[A] para nadar lentamente.\
Pulsa [A] sincronizadamente\
para ir mas rapido.\
Mueve el Control Stick\
para arriba y pulsa [A]\
para sumergirte.\
\
Mueve el Control Stick\
para abajo y pulsa [A]\
para volver a la\
superficie.\
Mueve el Control Stick\
abajo y pulsa [A] al borde\
del agua para salir de \
ella e ir la superficie."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("BRRR! Peligro de\
hipotermia! No nades aqui\
ni de chiste. Seriamente:\
/-El Pinguino"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("Escondida en un bloque\
verde, esta la gran\
Gorra Metalica.\
Poniendotela, no te\
quemaras o seras\
golpeado por enemigos.\
Ni siquiera tienes que\
respirar al usarla.\
\
El unico problema:\
No Puedes Nadar."))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("La gorra invisible esta\
dentro del bloque azul.\
Sr. I estara sorprendido,\
podras ser invisible\
cuando la uses!\
Hasta el gran boo podra\
ser enganado y podras\
atravesar las paredes\
secretas."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("Cuando te pongas la Gorra\
Alada que sale del\
bloque rojo, haz un\
Triple Salto para volar\
en el vasto cielo.\
Usa el Control Stick para\
dirigir a Mario. Hala\
atras para ir arriba,\
arriba para ir abajo,\
y pulsa [Z] para aterrizar."))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("Lecciones de natacion!\
Pulsa [A] para nadar.\
Si pulsas en el momento\
adecuado, nadaras mas\
rapido.\
\
Manten pulsado [A] para\
nadar a pataditas.\
Mueve el Control Stick\
hacia arriba para bucear\
y al lado opuesto\
para ir a la superficie.\
Para saltar fuera del\
agua, mueve el Control\
Stick abajo y luego\
pulsa [A]. Pan comido,\
verdad?\
\
Pero recuerda:\
Mario no puede respirar\
bajo el agua! Vuelve a la\
superficie para recuperar\
aire cuando te falte\
oxigeno.\
Una ultima cosa: No\
puedes abrir puertas que\
estan bajo el agua."))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("Mario, soy yo, Peach!\
Ten cuidado! Bowser\
es muy malvado! Intentara\
quemarte con su\
horrible aliento igneo.\
Corre detras de el y \
agarralo de su cola\
pulsando [B]. Cuando lo\
tengas mantenlo, giralo\
en grandes circulos.\
Rota el Control Stick\
para ir mas y mas rapido.\
Mientras mas rapido lo\
gires, volara mas lejos.\
\
Usa los botones [C] para\
mirar a tu alrededor, Mario.\
Tienes que tirar a Bowser a\
una de las bombas en las\
cuatro esquinas.\
Apunta bien, pulsa [B]\
para lanzar a Bowser.\
Buena suerte! Nuestro\
destino esta en tus manos."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("Mala suerte, Mario!\
La Princesa no esta\
aqui...Gua ja ja!!\
Vamos! Intenta agarrarme\
de la cola!\
Jamas me daras vueltas!\
Un debilucho como tu\
NUNCA podra arrojarme\
de aqui! Nunca! Ja!"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("Son Tierras Volcanicas!\
si te da el fuego o caes\
a la piscina de lava,\
estaras en llamas, pero\
no pierdas tu razon de\
sentido. Aun puedes\
controlar a Mario,\
solo no te desesperes!"))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("De vez en cuando chocaras\
con paredes invisibles\
en los mundos. Si chocas\
con una mientras vuelas,\
rebotaras hacia la\
direccion contraria."))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("Puedes volver al salon\
principal del castillo desde\
cualquier mundo\
donde los enemigos viven.\
Solo detente en donde\
estas, presiona Start\
para pausar el juego y\
selecciona en el menu\
Salir del nivel.\
\
No tienes que obtener\
todas las Estrellas de\
un nivel para ir al\
siguiente nivel.\
\
Regresa cuando tengas\
experiencia para agarrar\
las Estrellas mas dificiles.\
\
\
Cuando encuentres una\
Estrella, una pista para la\
siguiente se encontrara en\
la pantalla de inicio del\
nivel.\
\
Aun asi, puedes recolectar\
cualquiera de las\
Estrellas. No necesitas\
recolectar la que describe\
la pista."))

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, ("Peligro adelante!\
Cuidado con la extrana\
nube! No lo inhales!\
si te sientes debil, busca\
un terreno Elevado y\
aire puro!\
Circulo: Refugio\
Flecha: Entrada-Salida"))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("Fuertes vientos delante!\
Agarrate bien de tu gorra.\
Si sale volando,\
tendras que buscarla\
en la montana."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Aarrgh! Ahoy, marinero.\
Tengo este tesoro,\
aqui, Aqui lo tengo.\
\
Pero para conseguirlo,\
deberas abrir los\
Cofres en el\
orden correcto.\
Cual orden es ese,\
estas diciendo?\
\
\
Nunca lo dire!\
\
//--El Capi'"))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("Puedes agarrarte de un\
un acantilado o esquina\
con tus dedos y\
colgarte de estos.\
\
Para bajarte de la esquina,\
presiona el Control Stick\
en la direccion de la\
espalda de Mario o\
presiona el boton [Z].\
Para subir a la esquina,\
Presiona adelante en el\
Control Stick o presiona [A]\
Tan pronto que agarres la\
esquina para subir rapido."))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("Mario!! Mi castillo esta\
en un gran peligro. Se\
que Bowser es la causa...\
y se que solo tu puedes\
pararlo!\
Las puertas del castillo\
que han sido selladas por\
Bowser solo se abriran\
con Poder Estelar.\
\
Pero hay caminos\
secretos en el castillo,\
caminos que Bowser no\
pudo encontrar.\
\
Uno de esos caminos esta\
en esta sala, y tiene\
una de las Estrellas\
secretas del castillo!\
\
Busca la Estrella Secreta,\
Mario! Eso ayudara\
en tu aventura. Por favor,\
Mario, tienes que\
ayudarnos!\
Consigue todas las\
Estrellas en el castillo\
y liberanos de esta\
asquerosa prision!\
Por favor!"))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("Gracias al poder de\
las Estrellas, la vida del\
castillo esta volviendo.\
Mario, por favor, patea\
a Bowser de aqui!\
\
Dejame decirte algo\
sobre el castillo. En\
el cuarto de los espejos,\
mira cuidadosamente\
cualquier cosa que no\
se refleje en el espejo.\
y cuando vallas a sequias\
humedas, podras inundar\
todo, dependiendo de que\
tan alto entres a la\
pintura. Por cierto,\
mira lo que encontre!"))

smlua_text_utils_dialog_replace(DIALOG_077,1,2,150,200, ("Esta decretado, uno debe\
pisotear los pilares."))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("Rompe los Bloques de\
Monedas Azules con un\
Pisoton con el boton [Z] .\
Una Moneda Azul vale\
cinco Monedas Amarillas.\
Pero apresurate!\
Las monedas desvanecen\
si no las recojes\
rapido! Muy mal."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("Owww! Dejame!\
Uukee-kee! Solo era\
un juego! Que no sabes\
jugar?\
Te propongo algo, vamos\
a negociar. Si me dejas,\
te dare algo muyyyy\
especial.\
Que te parece?\
\
//Liberarlo/ Sostenerlo"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("Eeeh jee jee jee!"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("El misterio de una Sequia\
Humeda.\
Y donde esta\
la solucion?\
Esta ciudad con visitantes\
de las profundades atraen\
a quien entre."))

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, ("Agarra tu sombrero!\
Si lo pierdes, te\
haran mas dano\
\
Si pierdes tu gorra\
tendras que encontrarla\
en el nivel en el que\
la perdiste.\
Oh, esto no se ve bien\
para Peach. Ella sigue\
atrapada en algun lugar\
dentro de las paredes.\
Por favor, Mario, tienes\
que salvarla! Sabias que\
hay mundos dentro\
de las paredes, verdad?\
Si, es verdad, las tropas\
de Bowser estan ahi.\
Oh, toma esto. lo\
guarde para ti."))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("Hay algo extrano sobre\
ese reloj. Mientras saltas\
adentro, mira la posicion\
de la manecilla grande.\
Oh, mira que encontre!\
Mario, atrapalo!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Ouuuch! Sueltame,\
bruto! Llego tarde, muy\
tarde, tengo que\
apresurarme! Esta cosa\
brillante? Mia! Es mia.\
El que lo encuentra\
se lo queda... Tarde,\
tarde... Ouch! Tomalo!\
Un regalo de Bowser, es.\
Ahora dejame ir! Tengo\
una cita! No puedo llegar\
tarde a la hora del te!"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("La gente como tu no\
tiene oportunidad en\
esta casa. Aunque si\
caminas fuera de\
aqui te mereces...\
...una booena medalla..."))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("Al dar vueltas en circulos\
haces que algunos de los\
enemigos se mareen."))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("Santa Claus no es el \
unico que puede entrar\
por chimeneas! Entra!\
/-Propietario"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("Elevador de trabajo\
Para quienes bajen aqui:\
favor de usar el poste a\
la izquierda y bajar\
con cuidado."))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("Ambos caminos llenos de\
peligro! Sean cuidadosos!\
Aquellos que no puedan\
hacer Saltos Largos,\
Dirijanse hacia la derecha.\
Elevador de la derecha\
/// Cueva nublada\
Izquierda: Abismo\
///Lago Subterraneo\
\
Circulo rojo: Elevador 2\
//// Lago Subterraneo\
Flecha: Estas aqui"))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("Bua ja ja ja!\
Caiste en mi trampa,\
justo como esperaba.\
Pero te advierto,\
『Amigo,』 Cuida tus\
pasos!"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("Peligro!\
Rafagas fuertes!\
Pero el viento hace que\
sea un paseo comodo."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("Molestando otra vez,\
Mario? Que no ves\
que estoy pasandola bien,\
haciendo desastres con\
mis tropas?\
Ahora, regresa esas\
estrellas! Mis tropas\
en las paredes las\
necesitan! Bua ja ja!"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("Mario! Tu otra vez?!\
Esto es perfecto, estaba\
buscando algo que freir\
con mi aliento de fuego!\
El poder de las\
estrellas es inutil\
contra mi!\
Todos tus amigos estan\
atrapados en las\
paredes del castillo,\
Y no volveras a ver\
a la princesa jamas!\
Bua ja ja!"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("Da un buen aceleron\
cuesta arriba! Recuerdas\
el Salto Largo? Corre,\
pulsa [Z], luego salta!"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("Para leer una senal, ponte\
en frente y presiona [B],\
como lo acabas de hacer.\
\
Cuando quieras conversar\
con un Koopa Troopa u\
otro animal, ponte\
enfrente de el.\
Porfavor recupera las\
Estrella robadas por\
Bowser en este nivel."))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("Este camino es estrecho.\
Ve con calma! No esta\
permitido ir a la cima\
de la fortaleza!\
Y si sabes lo que es\
bueno para ti, no\
despertaras a nadie\
durmiendo!\
Muevete despacio,\
pisa ligeramente."))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("No te dejes! Si alguien te\
intenta empujar por ahi,\
empuja de vuelta! Que sea\
uno-a-uno, con un ardiente\
final para el perdedor!"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("Ven ven...\
...je, je, je..."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("Eh he he...\
You're mine, now, hee hee!\
I'll pass right through\
this wall. Can you do\
that? Heh, heh, heh!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("Ukkiki...Wakkiki...kee kee!\
Ja! La agarre!\
Es mia! JeeJeeJeeee!"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("Ackk! Sueltame...\
Me...ahorcas...\
Cough... Me atrapaste!\
La gorra? Esta bien,\
tomala. Me gusta la gorra,\
pero te la devolvere.\
Sigo pensando que se ve\
mejor en mi que en ti!\
Eeeee! Kee keee!"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("Pssst! Los Boos son super\
timidos. Miralos\
a los ojos, y se\
iran, pero si dejas\
de mirarlos, volveran.\
No trates de golpearlos\
cuando se vayan,\
mejor, escondete\
detras y asustalos."))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("LSobre las cuatro torres\
uno debe estar...\
entonces en la cima\
la luz brillara..."))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("La estrella gris delante\
de ti es un 『Marcador\
Estelar』. Cuando consigas\
8 Monedas rojas, una\
Estrella aparecera aqui."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Listo para lanzarte!\
Ven, salta al canon!\
\
Puedes conseguir algo en\
la isla flotante\
usando los cuatro canones.\
Usa el Control Stick para\
apuntar y pulsa [A] para\
lanzarte.\
Si eres cuidadoso, te\
podras agarrar de los\
arboles o postes."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Listo para el despegue!\
Vamos, entra al canon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("Los fantasmas\
...no...\
...MUEREN!\
Je, je, je!\
Podras salir de aqui...\
...con vida?"))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("Boooooo-m! Aqui viene\
el maestro de la malicia,\
el titan del horror,\
El Gran Boo!\
JA ja ja ja..."))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("Ooooh Nooooo!\
Hablando de manera\
corporal, mi cuerpo\
se ha derretido!\
Te has topado con un\
cazador de cabezas??\
Claro que puedo usar\
un nuevo cuerpo!\
Brrr! Mi cara se\
congelara asi!"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("Necesito una buena cabeza\
en mis hombros. Conoces a\
alguien que necesite un\
cuerpo? Por favor! Si\
sabes te seguire!"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Perfecto! Que buen\
cuerpo nuevo! Toma,\
acepta este regalo para\
ti. Estoy seguro que\
te quitara el frio."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("CRecolecta todas las\
monedas! Estas rellenan\
tu medidor de poder.\
\
Puedes ver cuantas\
monedas has\
recogido en cada uno\
de los 15 mundos.\
Tambien recuperas\
poder al tocar el\
Corazon Giratorio.\
\
Mientras mas corras\
a traves del corazon,\
mas poder recuperas."))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("Hay Gorras especiales en\
los bloques rojos, verdes\
y azules. Parate sobre los\
switches en los niveles\
secretos que activan los\
Bloques Gorra."))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("Estoy enojado! Nosotros\
construimos casas, tus\
castillos. Pavimentamos\
calles, y todavia nos\
pasan por encima.\
Acaso dijeron Gracias?\
No! No te limpiaras los\
pies en mi ahora!\
Creo que te aplastare\
solo por diversion!\
Acaso hay un problema\
con eso? Solo trata de\
golpearme, debilucho!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("No! Aplastado otra vez!\
Parece que solo soy un\
escalon despues de todo,\
pero, no me degravare\
em, degradare. Toma,\
tu ganas. Llevatelo!"))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Queeee?!?\
Pudo alguien tan\
debilucho como tu haber\
derrotado al Rey\
Bob-Omba???? Puede\
que me hayas vencido\
rapido, pero tendras que\
agarrar el ritmo si\
quieres agarrar al Rey\
Bowser de la cola.\
Creo que mis tropas\
aprenderan de ti!\
Toma tu estrella, como\
prometi, Mario.\
\
Si me quieres volver a\
ver, elige este nivel\
desde el menu. Por\
ahora, me despido."))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Quien...caminar...aqui?\
Quien...romper...sello?\
Despertar..antiguos?\
No gustar luz...\
Baaaataallarrrrr...\
No gustar...intrusos!\
Ahora pelear...\
...mano...\
...a...\
...mano!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Uuuuurrkkk!\
Que...paso?\
Nosotros...aplastados.\
Eres fuerte!\
Tu reinar aqui!\
Por ahora...\
Rojo, tomar Estrella.\
Nosotros...dormir...."))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("Grrr! Fui un poco\
descuidado. Esto no es lo\
que tenia en mente. Pero\
aun tengo el poder de las\
estrellas y a Peach\
a mi merced.\
Bua ja ja! No conseguiras\
mas estrellas de mi! Aun \
no hemos terminado,\
asi que te dejare ir por\
ahora. Pagaras por esto.\
Adios!"))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("Aaargh! Como es que pude\
perder??? El poder de las\
Estrellas me ha fallado...\
esta vez.\
Considera esto un empate.\
La proxima, Estare en\
perfectas condiciones.\
\
Ahora, si quieres ver a\
tu preciada Princesa,\
ve a la cima de la\
torre.\
Estare esperando!\
Mua ja ja ja!"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("ooo! no puede ser!\
Enserio me has vencido,\
Mario?!! Le di a mis\
tropas poder, pero\
ahora se ha ido!\
Arrgghh! Puedo ver la paz\
volviendo a la paz! No lo\
entiendo! Hmmm...\
No se ha acabado...\
\
Vamos tropas! Veamos\
el final juntos!\
Mua ja ja!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("El Agujero Negro\
Derecha: Elevador\
/// Laberinto Nube\
Izquierda: Lago Hondo "))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("Caverna de Metal\
Derecha: Cascada\
Izquierda: Switch Gorra"))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("Ascensor de trabajo\
Peligro!!\
Leer las instrucciones\
cuidadosamente!\
El ascensor avanza\
en direccion estrecha\
una vez activado."))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("Swooper-Salida\
Peligro! Cerrado.\
Da la vuelta."))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("Up: Black Hole\
Arriba: Fosa Negra\
Izquierda: Elevador\
/// Laberinto"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Lago Subterraneo\
Derecha: Cueva de Metal\
Izquierda: Mina Olvidada\
///(Cerrada)\
Un delicado Dino vive\
aqui. Golpealo para\
que baje su cabeza.\
No seas su comida."))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("Debes pelear con\
honor! Es en contra de\
las reglas reales, tirar\
tal rey fuera del ring!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("Bienvenido a la Fosa de\
la Gorra Invisible!\
Todos los bloques azules\
se solidificaran al\
pisar el Switch Gorra.\
Desapareceras cuando te\
pongas la Gorra Invisible,\
podras enganar a los\
enemigos y caminar entre\
objetos. Dale un Vistazo!"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("Esta es la Caverna de la\
Gorra Metalica! Salta\
en el Switch Gorra,\
los bloques verdes\
seran solidos.\
Cuando te vuelves\
metalico con la Gorra\
de Metal, puedes andar\
bajo el agua! Pruebalo!"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("Bienvenido a la Torre de\
la Gorra Alada! Parate en\
el switch rojo encima de \
la torre, en el centro de\
los anillos arcoiris.\
Cuando actives el\
switch, todos los\
bloques rojos vistos\
seran solidos.\
\
Prueba la Gorra alada!\
Has el Triple Salto\
para volar y presiona\
[Z] para caer.\
\
Pulsa atras en el Control\
Stick para volar y pulsa\
adelante para aterrizar,\
tal como hacer volar un\
avion."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Wow, Mario, amigo, estas\
intentando enganarme,\
no? Los trucos no\
son permitidos.\
Ahora, Se que puedes\
hacerlo mejor. Estas\
descalificado! La\
proxima, haslo bien!"))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("Me alegro de verte!  La\
princesa ... y yo ... y,\
bueno, todos ... estamos\
atrapados dentro de los\
muros del castillo.\
\
Bowser ha robado las\
Estrellas del castillo, y el\
esta usando su poder\
para crear mundos dentro\
de las pinturas y paredes.\
\
Recupera las estrellas\
de poder! Puedes usar el\
poder de las estrellas\
para abrir las puertas\
que Bowser ha sellado.\
\
Hay cuatro habitaciones\
en este piso. Empieza en\
la pintura que tiene una\
imagen de una bob-omba.\
Es la unica puerta que\
Bowser no ha sellado.\
Cuando consigas ocho\
Estrellas de Poder, tu\
podras abrir la puerta\
con la gran estrella. La\
Princesa debe estar ahi"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("Los nombres de las\
estrellas dan pistas para\
encontrarlas. Estas\
se muestran al inicio\
de cada nivel.\
Puedes recolectar estrellas\
En desorden. Pero no\
estaran algunas estrellas\
o enemigos si no entras\
en una estrella especifica.\
despues de recolectar una\
estrella, puedes intentar\
otro nivel.\
Todos estamos esperando\
tu ayuda"))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("Fue Bowser quien robo\
las estrellas. Lo vi con\
mis propios ojos!\
\
\
El ha escondido seis\
estrellas en cada mundo.\
Pero no encontraras\
todas, hasta que tengas\
todas las gorras.\
Las estrellas que has\
obtenido, se mostraran\
en el inicio del nivel.\
\
\
Si quieres ver a algun\
enemigo que ya has\
derrotado, selecciona\
la estrella que\
recuperaste de el."))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("Guau! Ya recuperaste\
tantas estrellas?\
Asi se hace, Mario! \
Apuesto que nos sacaras\
De aqui en poco tiempo\
\
Pero ten cuidado.\
Bowser escribio un\
libro del maldad.\
Toma mi consejo: cuando\
necesites recuperarte\
agarra varias monedas.\
Las monedas amarillas\
te recuperan una pieza,\
Las rojas te dan dos\
piezas y las azules dan\
cinco piezas.\
\
Para que aparezcan las\
monedas azules golpea\
los bloques de moneda\
azul.\
\
\
Ademas, si caes de una\
gran altura, tu podras\
minimizar el dano si\
haces un pisoton\
mientras aterrizas."))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("Gracias! El castillo\
esta obteniendo energia\
con las estrellas de\
poder y has perseguido\
a Bowser fuera de aqui,\
hacia un area adelante.\
Oh, por cierto estas\
recolectando monedas?\
Estrellas especiales\
aparecen al recolectar\
100 monedas en cada\
uno de los 15 mundos!"))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Abajo: Lago Subterraneo\
Izquierda: Agujero Negro\
Derecha: Laberinto"))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("Arriba: Ascensor Mecanico\
El elevador se inicia\
automaticamente y sigue\
un curso predeterminado.\
NOTA: Tambien desaparece\
automaticamente."))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("Elevador\
Derecha: Laberinto\
/// Entranda\
Izquierda: Agujero\
///Elevador 1\
Flecha: Estas aqui"))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("Has recuperado una de\
las Estrellas de Poder!\
Ahora puedes abrir\
algunas puertas selladas\
en el castillo.\
Intenta abrir la\
habitacion de la\
Princesa y la sala\
con la pintura de\
la Fortaleza Whomp.\
Las tropas Bowser estan\
ganando poder, asi que\
no te rindas. Salvanos,\
Mario! Sigue buscando\
las Estrellas!"))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("Has recuperado tres\
Estrellas de Poder! Ahora\
puedes abrir puertas con\
un 3 en su estrella.\
\
Puedes entrar y salir de\
los mundos abiertos cuando\
quieras. Los nuevos\
enemigos son mas fuertes,\
asi que se cuidadoso!"))

smlua_text_utils_dialog_replace(DIALOG_143,1,6,150,200, ("Has recuperado ocho\
Estrellas de Poder! Ahora\
puedes abrir la puerta con\
la gran Estrella! Pero\
Bowser esta esperando...\
escuchas a la Princesa?"))

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, ("Has recuperado 30\
Estrellas de Poder!\
Ahora puedes abrir la\
puerta con la gran\
Estrella! Pero antes de\
seguir, como te va?\
Has aplastado las dos\
columnas abajo? No has\
perdido tu sombrero, no?\
Si lo hiciste, debes de\
golpear al condor y\
recuperarlo!\
Dicen que Bowser ha\
salido del mar\
y ha ido bajo tierra.\
Ya lo has\
arrinconado?"))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("Has recuperado 50\
Estrellas de Poder\
Ahora puedes abrir la\
Puerta Estrella en el\
tercer piso. Bowser\
esta ahi, ya sabes.\
Oh! Acabas de encontrar\
todos los Switches Gorra,\
no? Rojo, verde y azul?\
Las Gorras que tienes de\
los bloques coloreados\
son de gran ayuda.\
Date prisa, ahora. El\
Tercer piso te espera."))

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, ("Has encontrado 70\
Estrellas de Poder!\
El misterio de las\
escaleras infinitas se\
ha resuelto, por ti--\
y Bowser esta molesto!"))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("Estas usando el Bloque\
Gorra? Realmente\
deberias, sabes?\
\
\
Para hacerlo solido, asi\
poder romperlo, necesitas\
presionar los Interruptores\
Gorra en los niveles\
secretos del castillo.\
Encontraras niveles\
secretos solo cuando\
consigues algunas\
Estrellas de Poder.\
\
Los Bloques Gorras son de\
gran ayuda! Rojo para la\
Gorra Alada, verde para la\
Gorra Metalica, azul para\
la Gorra Invisible."))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("Montana Nevada al frente.\
Fuera! Y no intentes\
el Triple Salto encima del\
dispensador de hielo.\
\
\
Si caes a el estanque\
congelado, perderas\
poder rapidamente, y\
no la recuperaras\
automaticamente.\
//--El Muneco de Nieve"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("Bienvenido a la\
resbaladilla secreta\
de la Princesa!\
Aqui hay una Estrella\
escondida que Bowser\
no pudo encontrar.\
Cuando te deslices, pulsa\
adelante para acelerar,\
pulsa atras para ir lento.\
Si te deslizas rapido,\
ganaras la Estrella!"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("Waaaa! Inundaste mi\
casa! Po-porque?? Mira\
este desastre! Que hare\
ahora?\
\
El techo esta arruinado,\
el piso esta mojado... que\
hare, que hare? Suspiro...\
Suspiro...me hace sentir...\
ENOJADO!!!\
Todo ha salido\
mal desde que tengo\
esta Estrella...Es \
brillante, pero me hace\
sentir... extrano..."))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("Ah! Ya no aguanto\
mas! Primero entras\
y me mojas, ahora\
me pisas!\
Ahora estoy realmente,\
REALMENTE enojado!\
Waaaaaaaaaaaaaaaaa!!!"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("Ouuch! Tio! Tio!\
Okay, Me Rindo. Toma\
esta estrella!\
Uf! Me siento mejor.\
No la necesito\
despues de todo--\
Puedo ver estrellas\
en mi techo en la\
noche.\
Me hacen sentir...\
...calmado. Porfavor,\
vuelve y visitame."))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("Hey! Who's there?\
Hey! Quien esta ahi?\
Que me esta trepando?\
Es una hormiga congelada?\
Una pulga nevada?\
Lo que sea que es, me\
esta molestando! Pienso\
que la soplare!"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("Hold on to your hat! If\
Agarra tu sombrero! si\
Lo pierdes te haras\
mas dano. Si lo\
pierdes, buscalo en el\
nivel donde lo perdiste\
hablando de perdido, la\
Princesa esta atrapada\
En algun muro\
Ayudala, Mario!\
\
Oh, sabes que hay\
Mundos secretos en las\
Paredes ademas de las\
pinturas, verdad?"))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("Gracias al poder de\
las estrellas, la vida del\
Castillo esta volviendo\
Mario, Por favor, patea\
A Bowser de aqui!\
\
Dejame decirte algo sobre\
el castillo. En el cuarto\
que tiene los espejos,\
mira con atencion\
cualquier cosa que no\
se refleje en el espejo.\
y cuando vayas a sequias\
humedas, podras inundar\
todo, dependiendo de que\
tan alto entres a la\
pintura."))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("El mundo dentro del\
Reloj es tan extrano!\
Cuando saltes adentro,\
mira la posicion de la\
gran manecilla!"))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("Cuidado! No dejes\
que te trague la\
arena movediza.\
\
\
Si te hundes en la arena,\
no podras saltar,\
y si tu cabeza\
se hunde, seras\
sofocado.\
Las areas oscuras son\
pozos sin fondo."))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("1. Saltar repetidamente\
y correctamente, hara\
saltar mas y mas alto.\
Correr rapido y al\
hacer tres saltos,\
hara un Triple Salto.\
2. Salta en una pared,\
luego salta de nuevo al\
tocar la pared. Puedes\
rebotar y llegars alto\
usando el Salto Pared."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("3. Si paras, presiona [Z]\
para agacharte, despues\
salta, puedes hacer una\
Voltereta. Para hacer un\
Salto Largo, corre,\
presiona [Z], y salta."))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("Presiona [B] mientras corres\
para deslizarte\
atacando. Mientras te\
deslizas, presiona [A] o [B]."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("Mario!!!\
Mario!!!\
Eres realmente tu???\
He estado aqui desde\
nuestra ultima aventura!\
Ellos me dijeron que\
tal vez te veria si,\
esperaba aqui pero estuve\
a punto de perder la fe!\
Es verdad? Acabas\
realmente de vencer a\
Bowser? Y restaurar las\
Estrellas del castillo?\
Y salvar a la Princesa?\
Sabia que podias hacerlo!\
Ahora tengo un muy\
importante mensaje.\
Gracias por jugar Super\
Mario 64! Este es el\
fin del juego, pero no\
el final de la diversion.\
SIGUE JUGANDO.\
\
Equipo de Super Mario 64"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("No, no, no! No tu\
Otra vez!  No ves que\
estoy en un apuro?\
\
No tengo tiempo para\
luchar por la estrella,\
agarrala. No queria\
esconderla de ti...\
Es solo que estoy tan\
apurado. Eso es todo,\
ahora dejame libre.\
Owww! Liberame!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Noooo! Esta vez si\
me has vencido,\
Mario! No puedo parar\
de perder contra ti!\
\
Mis tropas...inutiles!\
Te dieron todas las\
Estrellas! Porque?!\
Hay 120 en total???\
\
Asombroso! Algunas\
en el castillo que\
perdi??!!\
\
\
Ahora veo la paz\
regresando al mundo...\
Oooh! Lo odio!\
No puedo ver--\
Me voy de aqui!\
Solo espera a la\
proxima. Hasta eso,\
cuida ese Control\
Stick!\
Mua ja ja!"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("Mario! Como vas, amigo?\
No he estado en\
las carreras ultimamente, \
no estoy en forma.\
Aun, siempre estoy para\
una carrera, \
especialmente contra un\
gran rival.\
Que dices?\
En sus marcas...listos...\
\
//Ya//// Espera"))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("No tomo responsabilidad\
por aquellos que\
se mareen y pasen\
por alto\
esta senal."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("Regresare pronto.\
Estoy entrenando,\
regresa luego.\
//--Koopa el Rapido"))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("Hola, si estas leyendo esto\
seguro nos conoces.\
\
\
XxCmbRxX, LuchoGamer\
Y Tikal\
somos quienes hicieron\
Esta traduccion no\
oficial Para sm64ex-coop.\
Espero lo disfrutes tanto\
como nosotros."))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("Hey! apartate! Esta es\
La segunda vez que me\
aplastas. Ahora si lo\
pediste, tu aliento de\
pasta!"))

smlua_text_utils_dialog_replace(DIALOG_169,1,4,30,200, ("Largo de aqui!\
Me refiero a ti!\
Arrgghh!\
\
Cualquiera que entre\
sin permiso a la cueva\
solo encontrara desastre."))

